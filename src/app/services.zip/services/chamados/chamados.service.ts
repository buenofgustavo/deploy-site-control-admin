import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_CONFIG } from 'src/app/config/api.config';
import { AuthserviceService } from '../authservice.service';
import { Chamados } from 'src/app/interface/chamados';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChamadosService {


  private apiUrl = `${API_CONFIG.baseUrl}/chamados`; // Use a URL da API a partir da configuração
  private apiUrl2 = `${API_CONFIG.baseUrl}/chamados/arquivos`; // Use a URL da API a partir da configuração

  authToken: string | null;

  constructor(private http: HttpClient, private authService: AuthserviceService) {
    this.authToken = this.authService.extractAuthToken();
  }

  cadastrarChamados(chamados: Chamados): Observable<Chamados> {
    if (!this.authToken) {
      throw new Error('Token JWT não encontrado, refaça o Login!');
    }
  
    const headers = new HttpHeaders().set('Authorization', `Bearer${this.authToken}`);
  
    // Enviando a requisição com o FormData
    return this.http.post<Chamados>(this.apiUrl, chamados, { headers });
  }

  cadastrarArquivosChamados(files: FileList, id: String): Observable<Chamados> {
    if (!this.authToken) {
      throw new Error('Token JWT não encontrado, refaça o Login!');
    }

    const formData: FormData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i], files[i].name);
    }
    const idString: string = id.toString()
    formData.append('id', idString);
  
    const headers = new HttpHeaders().set('Authorization', `Bearer${this.authToken}`);
  
    // Enviando a requisição com o FormData
    return this.http.post<Chamados>(this.apiUrl2, formData, { headers });
  }

  getAllChamados(): Observable<Chamados[]> {
    if (!this.authToken) {
        throw new Error('Token JWT não encontrado, refaça o Login!');
    }

    const headers = new HttpHeaders().set('Authorization', `Bearer${this.authToken}`);

    return this.http.get<Chamados[]>(`${this.apiUrl}`, { headers });
  }

}

